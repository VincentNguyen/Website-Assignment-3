<?php
  // Define database connection constants
  define('DB_HOST', 'webdesign4.georgianc.on.ca');
  define('DB_USER', 'db200210636');
  define('DB_PASSWORD', '23104');
  define('DB_NAME', 'db200210636');
?>
