<!--
File Name: aboutme.html
Author Name: Vincent Nguyen
Website Name: VNWorld
Desc: This page provides a description of the website owner.
-->
<!DOCTYPE html>
<html>
    <head>
        <title>Vincent Nguyen's - About Me</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="portfoliocss.css" media="screen" />
    
    </head>
    <body>
       <?php
       require_once('beginsession.php');
       require_once('connectvars.php');
       $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
       if(isset($_SESSION['user_id']))
       {
           
       
       ?>
        
        
          <form method="post" action="logout.php">
     Logged in as Admin         
    <input type="submit" value="Log Out" name="submit" />

  </form>
    <div id ="header">
        <img id="imglogo" src="images/vnimage.png" alt="logo"/>     
    </div>
        <div id="links">
                <ul>
             <li id="active"><a href="index.php" title="">Home</a></li>
                    <li><a href="aboutme.php" title="">About Me</a></li>
                    <li><a href="projects.php" title="">Projects</a></li>
                    <li><a href="services.php" title="">Services</a></li>
                    <li><a href="https://github.com/VincentNguyen" title="">GitHub</a></li>
                    <li><a href="contactme.php" title="">Contact Me</a></li>
                    <li><a href="businesscontacts.php" title="">Business Contacts</a></li>
                </ul>
      
    <div id ="selfimage">
        <img src="images/vinnin.jpg" alt="selfportrait"/>     
        <p>My name is Vincent Nguyen, I am currently attending Georgian College to become a computer programmer. 
            <br> I find it interesting and enjoy developing many different applications and websites.
            <br> I believe that technology is constantly evolving and there will always be a large demand for computer programmers.
            <br> In my free time I enjoy writing music and spending time with family & friends.
            <br> I also play games casually.
        </p>
    </div>
            
        </div>
               <footer>
            <p> Copyright 2013 ~ VNWorld </p>
        </footer> 
         <?php
       }
       else{
              header('Location: http://webdesign4.georgianc.on.ca/~200210636/VNWorld/index.php');
             
       }
        mysqli_close($dbc);
        ?>
    </body>
</html>
