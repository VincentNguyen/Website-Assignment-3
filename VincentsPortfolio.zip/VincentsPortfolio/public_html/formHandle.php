<?php
session_start();

try{
	$mySQLUsername = "200210636";
	$mySQLPassword = "yellow1";
	$dsn = "webdesign4.georgianc.on.ca";
	
	$database = new PDO($dsn, $mySQLUsername, $mySQLPassword);
}
catch(PDOException $ex)
{
	echo "OOPS there was an error connecting to the database";
	
}


$usernameFromUser = $_POST['username'];
$passwordFromUser = $_POST['password'];


$select_statement = "SELECT * FROM `users` WHERE `username` = '" . $usernameFromUser . "'  LIMIT 0 , 30";



$result = $database->query($select_statement);

$counter = 0;
$passwordFromDB = "";
foreach($result as $row)
{
	$counter++;
	
	$passwordFromDB = $row['password'];
	
}

for($i = 0; $i < $result->rowcount(); $i++)
{
	
}

if($counter < 1)
{
	echo "<h1>There was a problem with your username</h1>";	
}
else
{
	
	if($passwordFromUser == $passwordFromDB)
	{
		$_SESSION["username"] = $usernameFromUser;
		echo "<h1>Welcome to the site " . $usernameFromUser . " </h1>";
		echo "<a href=\"secondpage.php\">Second Page </a>";
	}
	else
	{
		echo "<h1>There was a problem with your password!</h1>";	
	}

}

$query = "INSERT INTO `demodatabasepm`.`users` (
			`ID` ,
			`username` ,
			`password`
			)
			VALUES (
			NULL , 'dave', 'davespassword'
			);";
			
			$insert_count = $database->exec($query);
			
			echo $insert_count;
			
$query = "UPDATE `demodatabasepm`.`users` SET `password` = 'password2' WHERE `users`.`ID` =1;";
			
			$insert_count = $database->exec($query);
			
			echo $insert_count;			
			

?>